package lesson2;

public class Main2 {
    public static void main(String[] args) {
        var myBalance = 10;
        System.out.println(myBalance);
    }
}


