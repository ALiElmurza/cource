package lesson2;

public class Main1 {
    public static void main(String[] args) {
        String name = "Милана";
        String  LongName = "69868by98lyb";

        System.out.println(name);
    }
}
