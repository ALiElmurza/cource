package lesson3;

public class Main1 {
    public static void main(String[] args) {
        String name = "Милана";


    }
}
