package lesson3;

public class User {
    public static void main(String[] args) {
        String name;
        int age;
        String phone;
        String email;
        double rating; //4.98
        boolean isOnline; //false

    }
}
